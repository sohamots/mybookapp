<div class="container">
    <!-- start: PAGE HEADER -->
    <div class="row">
        <div class="col-sm-12">
            <ol class="breadcrumb">
                <li>
                    <i class="clip-home-3"></i>
                    <a href="#">
                        Home
                    </a>
                </li>
                <li class="active">
                    Dashboard
                </li>
                <li class="search-box">

                </li>
            </ol>
            <div class="page-header">
                <h1>Dashboard <small>overview &amp; stats </small></h1>
            </div>
        </div>
    </div>
    
</div>
</div>